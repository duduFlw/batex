<?php
class Usuario
{
    private $id;
    private $login;
    private $senha;

    //Conexão com o banco e o statement \\
    private $conn;
    private $stmt;

    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getLogin()
    {
        return $this->$login;
    }
    public function setLogin($login)
    {
        $this->login = $login;
    }

    public function getSenha()
    {
        return $this->$senha;
    }
    public function setSenha($senha)
    {
        $this->senha = $senha;
    }

    public function __construct() {
        try {
            include ("conexao.php");
            
            //Cria conexão com o banco \\
            $this->conn = new PDO("mysql:host=$server; dbname=$database", $user, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $erro) {
            //Verifica se ocorreu erro de conexão com o banco de dados \\
            die ("Erro na conexão: " .$erro->getMessage());            
        }
    }

    public function __destruct(){
        //Fecha o statement e a conexão \\
        $this->stmt = null;
        $this->conn = null;
        if(!empty($this->stmt)) $this->stmt->close();
        if(!empty($this->conn)) $this->conn->close();
    }
}
?>