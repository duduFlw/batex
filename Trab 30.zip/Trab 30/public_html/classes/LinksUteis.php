<?php
 class LinksUteis
 {
    public $codigo;
    public $nome;
    public $endereco;

    //Conexão com o banco e o statement
    private $conn;
    private $stmt;

    public function getCodigo()
    {
        return $this->codigo;
    }
    public function setCodigo($codigo)
    {
        $this->codigo = $codigo;
    }

    public function getNome()
    {
        return $this->nome;
    }
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getEndereco()
    {
        return $this->endereco;
    }
    public function setEndereco($endereco)
    {
        $this->endereco = $endereco;
    }

    public function __construct() {
        try {
            include ("conexao.php");
            
            //Cria conexão com o banco 
            $this->conn = new PDO("mysql:host=$server; dbname=$database", $user, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $erro) {
            //Verifica se ocorreu erro de conexão com o banco de dados
            die ("Erro na conexão: " .$erro->getMessage());            
        }
    }
    
    public function __destruct(){
        //Fecha o statement e a conexão 
        $this->stmt = null;
        $this->conn = null;
        if(!empty($this->stmt)) $this->stmt->close();
        if(!empty($this->conn)) $this->conn->close();
    }

    public function addLinksUteis() {
        $retorno = false;
        try{
           
            // SQL para add um novo link
            $sql = " INSERT INTO linksuteis ".
                    " (nome, endereco) " .
                    " VALUES (:nome, :endereco)";

                   
            //Informa o comando SQL ao statement\\
            $this->stmt= $this->conn->prepare($sql);

            //Adiciona os valores aos parâmetros do statement\\
            $this->stmt->bindValue(':nome', $this->nome, PDO::PARAM_STR);
            $this->stmt->bindValue(':endereco', $this->endereco, PDO::PARAM_STR);


            if($this->stmt->execute()){
                $retorno = true;   
            }
                     

        } catch(PDOException $e) {
            //Caso ocorra um erro 
            echo $e->getMessage();                 
        }
            return $retorno;
}

public function listarLinksUteis(){
        $usuarios = array();
        try{
                //pesquisa o nome da usuario
                $sql = "SELECT * FROM linksuteis ";
                
                 //Informa o comando SQL ao statement
            $this->stmt= $this->conn->prepare($sql);

            
            //Executa o comando SQL
            if($this->stmt->execute()){
                // Associa cada registro a uma classe LinksUteis
                // Depois, coloca os resultados em um array
                $linksuteis = $this->stmt->fetchAll(PDO::FETCH_CLASS,"LinksUteis");              
                     
            } 
        }catch(PDOException $e) {
            //Caso ocorra um erro 
            echo $e->getMessage();                 
        }
            //retorno o array com os links uteis encontrados
            return $linksuteis;
        
    }     
    
 }


?>