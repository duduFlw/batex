<?php

class EventosCalendario  
{
    public $id;
    public $dateTime;
    public $nomeEvento;
    public $enderecoLink;
    public $categoria;
    public $repeticao;

    //Conexão com o banco e o statement \\
    private $conn;
    private $stmt;

    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }

    public function getDateTime()
    {
        return $this->dateTime;
    }
    public function setDateTime($dateTime)
    {
        $this->dateTime = $dateTime;
    }

    public function getNomeEvento()
    {
        return $this->nomeEvento;
    }
    public function setNomeEvento($nomeEvento)
    {
        $this->nomeEvento = $nomeEvento;
    }

    public function getEnderecoLink()
    {
        return $this->enderecoLink;
    }
    public function setEnderecoLink($enderecoLink)
    {
        $this->enderecoLink = $enderecoLink;
    }

    public function getCategoria()
    {
        return $this->categoria;
    }
    public function setCategoria($categoria)
    {
        $this->categoria = $categoria;
    }
    public function getRepeticao()
    {
        return $this->repeticao;
    }
    public function setRepeticao($repeticao)
    {
        $this->repeticao = $repeticao;
    }
    
    public function __construct() {
        try {
            include ("conexao.php");
            
            //Cria conexão com o banco \\
            $this->conn = new PDO("mysql:host=$server; dbname=$database", $user, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $erro) {
            //Verifica se ocorreu erro de conexão com o banco de dados \\
            die ("Erro na conexão: " .$erro->getMessage());            
        }
    }

    public function __destruct(){
        //Fecha o statement e a conexão \\
        $this->stmt = null;
        $this->conn = null;
        if(!empty($this->stmt)) $this->stmt->close();
        if(!empty($this->conn)) $this->conn->close();
    }
}
?>

