<?php
class ImagensMidiasSociais
{
    public $codigo;  //busca no banco
    public $nome;    // ok
    public $caminho; // (tenho que adicionar um padrão) para cada Item
    // public $dataDeInclusao; //criar função com o new date
    public $setor; //ok
    public $campanha; //ok
    public $dataInicio; //ok
    public $dataFinal; //ok
    public $periodoCorrespondente; // fazer com basse nos anteriores

    //Conexão com o banco e o statement \\
    private $conn;
    private $stmt;

     public function getCodigo()
    {
        return $this->codigo;
    }
    public function setCodigo($codigo)
    {
        $this->codigo = $codigo;
    }

    public function getNome()
    {
        return $this-> $nome;
    }
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getCaminho()
    {
        return $this-> $caminho;
    }
    public function setCaminho($caminho)
    {
        $this->caminho = $caminho;
    }

    public function getDataDeInclusao()
    {
        return $this-> $dataDeInclusao;
    }
    public function SetDataDeInclusao()
    {
        $this->dataDeInclusao = date ("Y-m-d"); // não sei se funciona
    }

    public function getSetor()
    {
        return $this-> $setor;
    }
    public function setSetor($setor)
    {
        $this->setor = $setor;
    }

    public function getDataInicio()
    {
        return $this-> $dataInicio;
    }
    public function setDataInicio($dataInicio)
    {
        $this->dataInicio = $dataInicio;
    }

    public function getDataFinal()
    {
        return $this-> $dataFinal;
    }
    public function setDataFinal($dataFinal)
    {
        $this->dataFinal = $dataFinal;
    }

    public function getPeriodoCorrespondente()
    {
        return $this-> $periodoCorrespondente;
    }
    public function setPeriodoCorrespondente($periodoCorrespondente)
    {
        $this->periodoCorrespondente = $periodoCorrespondente;
    }

    public function getCampanha()
    {
        return $this-> $campanha;
    }
    public function setCampanha($campanha)
    {
        $this->campanha = $campanha;
    }

public function __construct() {
    try {
        include ("conexao.php");
        
        //Cria conexão com o banco \\
        $this->conn = new PDO("mysql:host=$server; dbname=$database", $user, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $erro) {
        //Verifica se ocorreu erro de conexão com o banco de dados \\
        die ("Erro na conexão: " .$erro->getMessage());            
    }
}

public function __destruct(){
    //Fecha o statement e a conexão \\
    $this->stmt = null;
    $this->conn = null;
    if(!empty($this->stmt)) $this->stmt->close();
    if(!empty($this->conn)) $this->conn->close();
}

    public function addImgMdSociais() {
        $retorno = false;
        try{
           
            // SQL para add um novo link
            $sql = " INSERT INTO midiasSociais".
                    " (nome, caminho,  setor, campanha) " . // com a data "(nome, caminho, dataDeinclusao,  setor, dataIncio, dataFinal, periodoCorrespondente, campanha)" .
                    " VALUES (:nome, :caminho, :setor, :campanha)"; // com a data VALUES (:nome, :caminho, :dataDeinclusao, :setor, :dataIncio, :dataFinal, :periodoCorrespondente, :campanha)";
 
                   
            //Informa o comando SQL ao statement\\
            $this->stmt= $this->conn->prepare($sql);

            //Adiciona os valores aos parâmetros do statement\\
            $this->stmt->bindValue(':nome', $this->nome, PDO::PARAM_STR);
            $this->stmt->bindValue(':caminho', $this->caminho, PDO::PARAM_STR);
            // $this->stmt->bindValue(':dataDeInclusao', $this->dataDeInclusao, PDO::PARAM_STR);
            $this->stmt->bindValue(':setor', $this->setor, PDO::PARAM_STR);
            // $this->stmt->bindValue(':dataInicial', $this->dataInicial, PDO::PARAM_STR);
            // $this->stmt->bindValue(':dataFinal', $this->dataFinal, PDO::PARAM_STR);
            // $this->stmt->bindValue(':periodoCorrespondente', $this->periodoCorrespondente, PDO::PARAM_STR);
            $this->stmt->bindValue(':campanha', $this->campanha, PDO::PARAM_STR);

            if($this->stmt->execute()){
                $retorno = true;   
            }
                     

        } catch(PDOException $e) {
            //Caso ocorra um erro 
            echo $e->getMessage();                 
        }
            return $retorno;
}
}
?>