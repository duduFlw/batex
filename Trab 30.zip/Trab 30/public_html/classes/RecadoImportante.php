<?php
class RecadoImportante
{
    private $id;
    private $setor;
    private $mensagem;

    //Conexão com o banco e o statement \\
    private $conn;
    private $stmt;

    public function getId()
    {
        return $this->id;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function getSetor()
    {
        return $this->$setor;
    }
    public function setSetor($setor)
    {
        $this->setor = $setor;
    }

    public function getMensagem()
    {
        return $this->$mensagem;
    }
    public function setMensagem($mensagem)
    {
        $this->mensagem = $mensagem;
    }

    public function __construct() {
        try {
            include ("conexao.php");
            
            //Cria conexão com o banco \\
            $this->conn = new PDO("mysql:host=$server; dbname=$database", $user, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $erro) {
            //Verifica se ocorreu erro de conexão com o banco de dados \\
            die ("Erro na conexão: " .$erro->getMessage());            
        }
    }

    public function __destruct(){
        //Fecha o statement e a conexão \\
        $this->stmt = null;
        $this->conn = null;
        if(!empty($this->stmt)) $this->stmt->close();
        if(!empty($this->conn)) $this->conn->close();
    }
    
    public function addRecadoImportante() {
        $retorno = false;
        try{
           
            // SQL para add um novo link
            $sql = " INSERT INTO recadoImportante ".
                    " (setor, mensagem) " .
                    " VALUES (:setor, :mensagem)";

                   
            //Informa o comando SQL ao statement\\
            $this->stmt= $this->conn->prepare($sql);

            //Adiciona os valores aos parâmetros do statement\\
            $this->stmt->bindValue(':setor', $this->setor, PDO::PARAM_STR);
            $this->stmt->bindValue(':mensagem', $this->mensagem, PDO::PARAM_STR);


            if($this->stmt->execute()){
                $retorno = true;   
            }
                     

        } catch(PDOException $e) {
            //Caso ocorra um erro 
            echo $e->getMessage();                 
        }
            return $retorno;
}

}
?>