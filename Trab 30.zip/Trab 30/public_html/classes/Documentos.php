<?php
class Documentos 
{
    public $codigo;  //busca no banco
    public $nome;    // ok
    public $caminho; // (tenho que adicionar um padrão) para cada Item
    // public $dataDeInclusao; //criar função com o new date
    public $setor; //ok
    public $categoria; //aonde vai ser colocado (treinamentos, politicas, news) ok

    //Conexão com o banco e o statement \\
    private $conn;
    private $stmt;

    
    public function getCodigo()
    {
        return $this->codigo;
    }
    public function setCodigo($codigo)
    {
        $this->codigo = $codigo;
    }

    public function getNome()
    {
        return $this-> $nome;
    }
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getCaminho()
    {
        return $this-> $caminho;
    }
    public function setCaminho($caminho)
    {
        $this->caminho = $caminho;
    }

    // public function getDataDeInclusao()
    // {
    //     return $this-> $dataDeInclusao;
    // }
    // public function SetDataDeInclusao($dataDeInclusao)
    // {
    //     $this->dataDeInclusao = $dataDeInclusao;
    // }

    public function getSetor()
    {
        return $this-> $setor;
    }
    public function setSetor($setor)
    {
        $this->setor = $setor;
    }
    
    public function getCategoria()
    {
        return $this-> $categoria;
    }
    public function setCategoria($categoria)
    {
        $this->categoria = $categoria;
    }

public function __construct() {
    try {
        include ("conexao.php");
        
        //Cria conexão com o banco \\
        $this->conn = new PDO("mysql:host=$server; dbname=$database", $user, $password);
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $erro) {
        //Verifica se ocorreu erro de conexão com o banco de dados \\
        die ("Erro na conexão: " .$erro->getMessage());            
    }
}

public function __destruct(){
    //Fecha o statement e a conexão \\
    $this->stmt = null;
    $this->conn = null;
    if(!empty($this->stmt)) $this->stmt->close();
    if(!empty($this->conn)) $this->conn->close();
}

    public function addDocumento() {
        $retorno = false;
        try{
           
            // SQL para add um novo link
            $sql = " INSERT INTO documentos".
                    " (nome, caminho,  setor, categoria) " .
                    " VALUES (:nome, :caminho, :setor, :categoria)";

                   
            //Informa o comando SQL ao statement\\
            $this->stmt= $this->conn->prepare($sql);

            //Adiciona os valores aos parâmetros do statement\\
            $this->stmt->bindValue(':nome', $this->nome, PDO::PARAM_STR);
            $this->stmt->bindValue(':caminho', $this->caminho, PDO::PARAM_STR);
            // $this->stmt->bindValue(':dataDeInclusao', $this->dataDeInclusao, PDO::PARAM_STR);
            $this->stmt->bindValue(':setor', $this->setor, PDO::PARAM_STR);
            $this->stmt->bindValue(':categoria', $this->categoria, PDO::PARAM_STR);

            if($this->stmt->execute()){
                $retorno = true;   
            }
                     

        } catch(PDOException $e) {
            //Caso ocorra um erro 
            echo $e->getMessage();                 
        }
            return $retorno;
}
}
 ?>

