<?php
 class Arquivos
 {
    public $codigo;  //busca no banco
    public $nome;    // ok
    public $caminho; // (tenho que adicionar um padrão) para cada Item
    public $dataDeInclusao; //criar função com o new date
    public $setor; //ok

    public function getCodigo()
    {
        return $this->codigo;
    }
    public function setCodigo($codigo)
    {
        $this->codigo = $codigo;
    }

    public function getNome()
    {
        return $this-> $nome;
    }
    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getCaminho()
    {
        return $this-> $caminho;
    }
    public function setCaminho($caminho)
    {
        $this->caminho = $caminho;
    }

    public function getDataDeInclusao()
    {
        return $this-> $dataDeInclusao;
    }
    public function SetDataDeInclusao($dataDeInclusao)
    {
        $this->dataDeInclusao = $dataDeInclusao;
    }

    public function getSetor()
    {
        return $this-> $setor;
    }
    public function setSetor($setor)
    {
        $this->setor = $setor;
    }

    public function __construct() {
        try {
            include ("conexao.php");
            
            //Cria conexão com o banco \\
            $this->conn = new PDO("mysql:host=$server; dbname=$database", $user, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $erro) {
            //Verifica se ocorreu erro de conexão com o banco de dados \\
            die ("Erro na conexão: " .$erro->getMessage());            
        }
    }

    public function __destruct(){
        //Fecha o statement e a conexão \\
        $this->stmt = null;
        $this->conn = null;
        if(!empty($this->stmt)) $this->stmt->close();
        if(!empty($this->conn)) $this->conn->close();
    }

 }
?>