<?php 
    
    $server = "localhost";
    $database = "id13697633_wirutexbasso";
    $user = "id13697633_eduardoestagio";
    $password = "2020_estagioWirutex";

?>