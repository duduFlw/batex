<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
	</head>
	</body>
		<?php
			include_once("../classes/Documentos.php");
			
			echo $_POST["nomeDocumento"]."<br>";
			echo $_POST["caminho"]."<br>";
			echo $_POST["setorDoc"]."<br>";
			echo $_POST["categoriaDoc"]."<br>";
			
			$documento = new Documentos();

			$documento->setNome($_POST["nomeDocumento"]);
			$documento->setCaminho($_POST["caminho"]);
// 			$documento->setDataInclusao(new Date());
			$documento->setSetor($_POST["setorDoc"]);
			$documento->setCategoria($_POST["categoriaDoc"]);
			$retorno = $documento->addDocumento($_FILES['arquivo']['name']);
			
			if ($retorno[0] === true) {
				echo "<p>Novo Recado Importante adicionado com sucesso!<p>";
				
			} else {
				echo "Erro";
			}
			
		?>
	</body>
</html>