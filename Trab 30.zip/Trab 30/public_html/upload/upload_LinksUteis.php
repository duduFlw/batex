<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
	</head>
	</body>
	<?php
		include_once("../classes/LinksUteis.php");
			
// // 			echo $_POST["nomeDoLink"]."<br";
// // 			echo $_POST["enderecoDoLink"]."<br";
			
// 			$link = new LinksUteis();

// 			$link->setNome($_POST["nomeDoLink"]);
// 			$link->setEndereco($_POST["enderecoDoLink"]);
// 			$retorno = $link->addLinksUteis($_FILES['arquivo']['name']);
			
// 			if ($retorno[0] === true) {
// 				echo "<p>Novo Link adicionado com sucesso!<p>";
				
// 			} else {
// 				echo "Erro";
// 			}
        
            echo "<br><br>";        
		    $linkListar = new LinksUteis();
            $linksUteisL = $linkListar->listarLinksUteis();
    
            
            echo "<table border=1px>";
             
			foreach ($linksUteisL as $linha) {//cada linha é um link
			    	 echo "<tr>
				      <td style='padding: 12px'>". $linha->getCodigo() ."</td>
				      <td style='padding: 12px'>". $linha->getNome() ."</td>
				      <td style='padding: 12px'>". $linha->getEndereco() ."</td>
			    	  </tr>";
			}

		echo "</table>";
		?>

	</body>
</html>