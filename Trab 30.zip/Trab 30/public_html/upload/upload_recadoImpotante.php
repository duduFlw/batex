<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
	</head>
	</body>
		<?php
			include_once("../classes/RecadoImportante.php");
			
			echo $_POST["setorRecadoImportante"]."<br";
			echo $_POST["mensagem"]."<br";
			
			$recado = new RecadoImportante();

			$recado->setSetor($_POST["setorRecadoImportante"]);
			$recado->setMensagem($_POST["mensagem"]);
			$retorno = $recado->addRecadoImportante($_FILES['arquivo']['name']);
			
			if ($retorno[0] === true) {
				echo "<p>Novo Recado Importante adicionado com sucesso!<p>";
				
			} else {
				echo "Erro";
			}
			
		?>
		
	</body>
</html>