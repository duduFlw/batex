<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
	</head>
	</body>
		<?php
			include_once("../classes/ImagensMidiasSocias.php");
			
			echo $_POST["nomeImgMdSociais"]."<br>";
			echo $_POST["caminhoImgMdSociais"]."<br>";
			// data de inclusao
			echo $_POST["setorImgImgMdSociais"]."<br>";
			echo $_POST["campanhaImgMdSociais"]."<br>";
// 			echo $_POST["DataInicioImgMdSociais"]; // data inicial
			// data final
			// periodo correspondente 
			
			$imgMdSociais = new ImagensMidiasSocias();

			$imgMdSociais->setNome($_POST["nomeImgMdSociais"]);
			$imgMdSociais->setCaminho($_POST["caminhoImgMdSociais"]);
// 			$imgMdSociais->setDataInclusao(); acho que vai funcionar assim
			$imgMdSociais->setSetor($_POST["setorImgMdSociais"]);
			$imgMdSociais->setCampanha($_POST["campanhaImgMdSociais"]);
 			$imgMdSociais->setDataInicial($_POST["DataInicioImgMdSociais"]);
 			$imgMdSociais->setDataInicial($_POST["DataFinalImgMdSociais"]);
// 			$imgMdSociais->setPeriodoCorrespondente();
			$retorno = $imgMdSociais->addImgMdSociais($_FILES['arquivo']['name']);
			
			if ($retorno[0] === true) {
				echo "<p>Novo midia social adicionada com sucesso!<p>";
				
			} else {
				echo "Erro";
			}
			
		?>
	</body>
</html>
