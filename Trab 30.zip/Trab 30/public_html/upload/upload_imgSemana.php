<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
	</head>
	</body>
		<?php
			include_once("../classes/ImagensSemana.php");
			
			echo $_POST["nomeImgSemana"]."<br>";
			echo $_POST["caminhoImgSemana"]."<br>";
			// data de inclusao
			echo $_POST["setorImgSemana"]."<br>";
// 			echo $_POST["DataInicialImgSemana"]; // data inicial
			// data final
			// semana correspondente 
			
			$imgSemana = new imagensSemana();

			$imgSemana->setNome($_POST["nomeImgSemana"]);
			$imgSemana->setCaminho($_POST["caminhoImgSemana"]);
// 			$imgSemana->setDataInclusao(); acho que vai funcionar assim
			$imgSemana->setSetor($_POST["setorImgSemana"]);
// 			$imgSemana->setDataInicial($_POST["DataInicialImgSemana"]);
// 			$imgSemana->setSemanaCorrespondente();
			$retorno = $imgSemana->addImgSemana($_FILES['arquivo']['name']);
			
			if ($retorno[0] === true) {
				echo "<p>Novo Recado Importante adicionado com sucesso!<p>";
				
			} else {
				echo "Erro";
			}
			
		?>
	</body>
</html>
